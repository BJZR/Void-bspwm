#!/bin/bash

# Habilitar repositorios adicionales
sudo xbps-install -Sy void-repo-nonfree void-repo-multilib 
echo "[✓] Todo los paquetes instalados"